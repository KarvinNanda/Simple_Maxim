<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Confirmation</title>
</head>
<body>
        <h2><center>Thanks for using maxim</center></h2>
        <h3><center>Have a nice day</center></h3>
        <h2><center><a href="/"> >>> Home <<< </a></center></h2>
</body>
</html>
<?php /**PATH D:\Karvin\Binus\belajar with cinhe\Laravel\Laravel\templateKosong\template\resources\views/confirmation.blade.php ENDPATH**/ ?>